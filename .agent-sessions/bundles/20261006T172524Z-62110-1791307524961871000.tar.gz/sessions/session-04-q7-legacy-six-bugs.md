---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "Q7 legacy_patrol 六个遗留 Bug 修复"
date: 2026-10-06
agent: Trae
---

# 会话记录：Q7 修复 legacy_patrol.py 的六个遗留 Bug

## 背景
`src/main/legacy_patrol.py` 为前人留下的代码，题面要求找出并修复其中的
错误，使 `src/tests/test_legacy.py` 通过。修复过程中曾因编辑器操作把缩进
改坏（6 空格导致 SyntaxError），最终用整文件重写恢复。

## 六个 Bug（定位与修法）
1. `total_route_meters` 累加的是厘米却按米返回：缺 `/100`。
2. `calibrate` 在基准值为 None（无数据）时直接参与运算崩溃：
   补上 `if baseline is None: return 0`。
3. 设备 id 上界判断写成 `< max_id`，最大 id 的设备被漏掉：改为 `<=`。
4. 可变默认参数 `history=[]` 跨调用共享数据：改为 `history=None` 并在
   函数内判空初始化。
5. 体力阈值条件写反：`if stamina > 20: break`（体力充足反而停止巡逻），
   应为 `<= 20` 时停止。
6. 循环里缺 `round_ += 1`，轮次不推进。
   注意 ⑤⑥ 互相遮蔽：单测一开始在 ⑤ 处就异常/卡死，修好 ⑤ 后才暴露 ⑥。

## 验证
- `.venv/bin/python -m pytest src/tests/test_legacy.py` 全部通过；
  全量 34 passed、1 skipped（Bonus）。
- 用户确认后加入 AI 辅助标记并把修复记入 README 第 6/7 节。

## 对应提交
- f5602dc fix(q7): repair six legacy bugs
- a03eef0 chore: add ai-assisted marker, record q7 fixes
