---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "隐藏契约复核：Q7 parse_event 非字符串输入不抛异常"
date: 2026-10-07
agent: Trae
---

# 会话记录：针对"32 个坑、一半本地跑不出"的复核

## 用户要求
出题者提示共有 32 个坑、其中约一半本地可见测试跑不出来；要求再次检索并修正。

## 复核方法
- 从题面 PDF 提取 Q1-Q7/Bonus 规范，逐条对照当前磁盘实现（注意：编辑器打开的 src/main/__init__.py 是旧草稿缓冲区，实际以 shell/git 读取的磁盘内容为准）。
- 对 Q1 做阈值/格式探针；对 Q5 用按规则表直写的 oracle 随机核对 20000 组合法输入；对 Q7 parse_event 做非字符串输入探针；对 Q6 重跑 200 seed 阈值统计。

## 确认并修复
- Q7 legacy_patrol.parse_event：docstring 契约写明"脏行返回 None（不得抛异常）"，但实现对 line 直接 strip/split；None、int、bytes 会抛 AttributeError/TypeError。修复：入口增加 `if not isinstance(line, str): return None`。
- 其余区域未发现新的确定违约：Q1 档位与宽度符合模板；Q2 传感器正整数段、JSON id 去重、非字符串行跳过均已覆盖；Q3 构造复用 setter；Q4 候选/大轴优先/无候选返回当前朝向符合规范；Q5 oracle 20000 例一致；Q6 200 seed 100%/0.00/1.08。

## 验证
- parse_event 边界探针通过（None/123/bytes 均返回 None）。
- pytest：34 passed, 1 skipped。
- autopep8 --diff：空。
- tools/run_seeds.py --q6：成功率 100.0%、平均碰撞 0.00、步数/BFS 1.08，全 PASS。

## README
- 第 7 节新增第 19 条踩坑，记录该隐藏契约缺陷与定位方法；未改 1-5 节。
