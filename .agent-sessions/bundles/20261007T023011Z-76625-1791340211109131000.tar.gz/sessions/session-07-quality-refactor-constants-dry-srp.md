---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "代码质量重构：常量化、DRY、SRP（不改变行为）"
date: 2026-10-07
agent: Trae
---

# 会话记录：按六个坏味道信号做纯结构重构

## 用户要求
提升代码质量，规避课件截图中的六类问题：超长函数/超大类、魔法数字、
大量 if-else 嵌套、重复代码、过多全局变量、注释掩盖糟糕代码；并运用
KISS/DRY/SRP/高内聚低耦合/YAGNI 原则。明确约束：重构不改变功能。

## 排查与改动（src/main/__init__.py）
1. 魔法数字：Q1 电量档 60/20 提为 BATTERY_OK_MIN/BATTERY_LOW_MAX；
   Q5 的 30/3/6/2/100 提为 RETREAT_HP_PERCENT、ENGAGE_RANGE、
   MAX_FRAME_HISTORY、CONFIRM_FRAMES、DEFAULT_MAX_HP；Q6 的 1.25、2、1
   提为 WALL_BUDGET_FACTOR/WALL_EXIT_MARGIN 等；Q7 legacy 的
   100/8/5/3/20 提为同名常量。0/100 这类自明边界保留字面量，避免过度命名。
2. DRY：朝向旋转字典原来在 Q3 turn_left/turn_right、Q6 left_of/
   right_of/right_turns 共手抄三份，合并为模块级 TURN_LEFT_OF、
   TURN_RIGHT_OF（由左旋表求逆）、RIGHT_TURN_COUNT 单一事实源，
   Q3/Q4/Q6 共用。
3. SRP：analyze_damage_log 拆出 _parse_json_line、_parse_sensor_line
   两个校验函数，主函数只负责遍历、id 去重和汇总；有效事件先收集成
   列表再统一统计，三处累加变一处。顺手补规范第 3 条：非字符串行
   （None、int 等）直接跳过，不抛 AttributeError。
4. 超长函数：run_patrol 近 150 行、含两轮重复换手代码。拆出
   enter_wall_mode/switch_hand/follow_wall 三个单一职责嵌套函数；
   左右手差异用 hand_side/hand_away 映射与绑定方法表达，消除按手
   分支的重复 if-else；主循环缩短为可直读的状态流，并用 continue
   等价替换 switched_hand 标志位。
5. Q4 平局分组提为 _HORIZONTAL_FACINGS/_VERTICAL_FACINGS。
6. hp_ratio 增加 max_hp <= 0 防护（契约外输入返回 0 而非除零）。
7. Q1 两个已实现函数的陈旧 TODO docstring 改为契约描述；Bonus 的
   NotImplementedError 保留（该题未做）。

## 行为等价验证（重构前基线 100% / 0.00 / 1.08）
- pytest：34 passed, 1 skipped，重构前后一致。
- tools/run_seeds.py --q6：100.0% / 0.00 / 1.08（max 4.41），与重构前
  完全一致；--seeds 500 扩展区间同为 100% / 0.00 / 1.08。
- 边界探针：F:0 与 F:10,L:0 判脏、id 去重、无 id 独立计数、连转四次
  回原朝向等全部与重构前相同；None/123 等非字符串行不再抛异常。
- autopep8 --diff 零输出。

## 原则取舍
- YAGNI：没有为"可能的需求"加抽象；0/100 自明边界未命名；legacy 的
  事件类型元组仅用一次，未抽常量。
- 所有修改仍在 CI 白名单 src/main/** 内。

## README
新增"代码结构约定（重构后）"小节与踩坑第 17、18 条。

## 对应提交
- （随后续 refactor 提交进入 git）
