---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "Bonus：修正 BFS 最短路实现并通过排行榜"
date: 2026-10-07
agent: Trae
---

# 会话记录：Bonus BFS 修正

## 用户要求
用户自行编写了 Bonus 的 `bfs_path_length`，要求修正错误。

## 现场判断
- 磁盘上的 `src/main/__init__.py` 仍为 `NotImplementedError`，用户代码在 VS Code 未保存缓冲区中；该缓冲区还包含旧版 Q6 草稿，直接保存会覆盖磁盘上已完成的 Q6。
- 因此只提取用户 Bonus BFS 的算法意图，在磁盘正确版本上最小修改，不整盘保存旧缓冲区。

## 用户草稿中的错误
1. 队列节点写作 `(x, y, steps)`，扩展邻居时却引用未定义的 `dist`，非零距离路径会触发 `NameError`。
2. 先判断 `nxt == target`、后判断 `nxt in obstacles`，当目标格本身是障碍时会错误返回可达距离。
3. `deque` 导入位于文件中部，另有脱离函数的裸 docstring，不符合顶部导入和风格要求。

## 修复
- 顶部增加 `from collections import deque`。
- 用 `deque([(start, 0)])` 和 `visited={start}` 实现四邻域 BFS。
- `start == target` 先返回 0；邻居必须未访问且不在障碍中，再判断是否到达目标；耗尽队列返回 -1。
- 地图边界仍按 Bonus 契约由调用方放入 `obstacles`，函数不自行假定宽高。

## 验证
- 可见 pytest：35 passed（原 Bonus skip 已消失）。
- 固定用例：距离 10、同点 0、不可达 -1、目标格障碍 -1、可绕行距离 4 均通过。
- 使用独立 BFS 参考实现随机核对 5000 个带边界小图，结果一致。
- `tools/run_seeds.py --bonus`：BFS 正确；200 seed 排行榜为 100.0% 成功率、29.5 平均步数、0.0 平均碰撞。
- `tools/run_seeds.py --q6` 回归：100.0% / 0.00 / 1.08，全 PASS。
- autopep8 --diff 为空。

## README
- Bonus 小节替换占位说明，补 BFS 设计、5000 随机核对和排行榜数据。
- 踩坑记录新增第 20 条，说明距离变量名不一致和障碍判断顺序。
