---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "seed 180 失败定位：切入沿墙时未贴墙"
date: 2026-10-07
agent: Trae
---

# 会话记录：seed 180 为什么失败，以及修复

## 用户提问
"为什么 180 会失败？它也应该过。"——随后明确要求修掉。

## 定位过程（真实数据）
- seed 180：13x19 地图，35 个障碍，start (0,0) -> enemy (12,18)，
  BFS 最短路只有 30 步；旧策略跑满 500 步停在 (9,17)，距敌人 4 格。
- 程序化追踪逐帧动作与格子访问计数：每约 102 步重复同一个大循环，
  5 次进入 WALL 模式都发生在 (10,17)；真正的出口格 (11,16) 全程被踩 0 次。
- 根因：贪心在 (10,16) 平局时按竖直优先走 UP 进死路 (10,17)；切入沿墙
  模式时保持原朝向 UP，而左手侧 (9,17) 恰好是开阔空地——沿墙第一步
  "优先走手侧格"立即离开墙面，从出口旁边掠过，之后永远绕不回来。

## 修复
- 在 run_patrol 内新增 `stick_to_wall(hand)`：切入沿墙时以及每次换手后
  先原地转向，直到手侧格是障碍再起步（最多转 4 次）。
- 三个调用点：进入 wall mode 后；闭环检测触发 L->R 换手后；
  步数预算兜底换手后。转向不耗电、不计 steps，不改变指标口径。
- 用独立脚本在 500 个 seed 上验证修法后才落盘。

## 结果
- 200 张官方 seed：100.0% / 0.00 / 1.08（修复前 99.5% / 0.00 / 1.15）。
- seed 201-500：100% / 1.07（修复前 100% / 1.17），碰撞始终 0。
- 全量 pytest 34 passed, 1 skipped；autopep8 零 diff。

## 工具插曲
排查中确认 VS Code 编辑器缓冲区残留旧草稿（含 turn_left_facing 与
NotImplementedError 桩），与磁盘版本分叉；所有修改与验证均以磁盘文件和
pytest 实跑结果为准，并提示用户对文件执行 Revert File、勿直接保存。

## 对应提交
- ed89a02 fix(q6): align to wall on escape entry for full seed pass
- 8f07f63 docs: record q6 wall-entry fix and 100 percent result
