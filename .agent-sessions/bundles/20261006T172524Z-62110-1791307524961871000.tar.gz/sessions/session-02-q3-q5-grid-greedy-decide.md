---
cwd: /Users/hinh/Desktop/AIM/aim-2627-py-cw-20907385
title: "Q3-Q5 载体物理、贪心导航与决策机"
date: 2026-10-06
agent: Trae
---

# 会话记录：Q3 SentryGrid、Q4 贪心导航、Q5 决策机

## Q3 SentryGrid（载体物理）
- 实现 `current_pos` setter：非 tuple/list 抛 TypeError；长度 != 2 抛
  TypeError；随后复用已提供的 `_clamp_cell` 归一并检查障碍。
- `move_forward`：燃料 <= 0 时原地返回；目标格障碍或越界则碰撞计数 +1
  且不扣燃料；正常移动才扣 1 燃料并返回新位置。
- `turn_left` / `turn_right`：按世界坐标（x 右、y 上）的朝向表旋转，
  返回新的 Facing；转向不耗燃料。
- 本轮边界审计（10-07）发现构造函数最初直接调 `_clamp_cell(start_pos)`，
  与 setter 校验不一致：长度 3 的坐标会被静默截断、非法字符串抛 ValueError
  而非 setter 承诺的 TypeError。已改为构造末尾 `self.current_pos = start_pos`，
  校验只走一条路径。

## Q4 next_step_toward（单步贪心）
- 枚举四个朝向，只保留"严格缩短曼哈顿距离且非障碍"的邻居。
- 平局规则：x 差距大则水平优先，否则竖直优先；同组内再按
  RIGHT/LEFT、UP/DOWN 顺序取第一个，保证结果确定。
- 没有更优邻居时返回 current_facing（保持朝向，由上层脱困逻辑接管）。
- 注：本函数只看障碍集合，越界由调用方 grid.is_blocked 负责。

## Q5 decide（R1-R7 固定序决策）
- 先做输入校验与防御式归一：sensor 缺字段抛 ValueError；state 非枚举成员
  抛 ValueError；enemy_frames 允许标量或 1-6 帧序列；max_hp 非法回退 100；
  hp 无法转 int 时按 0 处理。
- 规则顺序固定：HP <= 30% 一律 RETREAT；RETREAT 态返 RETURN；RETURN 态
  回 PATROL（MOVE_BASE）；ENGAGE 态按可见/上一帧/丢失分别动作；
  首次可见需连续两帧才 ENGAGE（先 SUSPECT+SCAN），避免误触发。
- R4/R6 共用 `_engage_action`：敌距 <= 3 射击，否则 HERO 右移、其他左移。
- 本轮边界审计：敌距为负数是非法读数，旧代码只排除非 int 与 bool，
  -5 会通过 `<= 3` 误判贴脸射击。已把负数一并归一为 None（按未知距离
  侧移处理）；合法的 0-3 仍正常 SHOOT。

## 验证
- 可见测试全部通过；针对三处边界额外写了探针脚本验证行为与题面一致。
- 风格：autopep8 零 diff；79 列、美式英语注释。

## 对应提交
- 5858ff8 feat(q3-q5): grid movement, greedy nav, decision rules
- 9821967 fix(q2,q3,q5): harden sensor zero, ctor setter, negative dist
